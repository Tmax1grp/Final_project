import React from 'react';

export default function ChatMessageInputCard(props) {
    return (
        <>

        </>
    );
}