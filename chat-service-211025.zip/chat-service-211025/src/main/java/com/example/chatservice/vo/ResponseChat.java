package com.example.chatservice.vo;

import java.util.Date;

public class ResponseChat {
    private String classId;
    private String fromId;
    private String toId;
    private String chatContent;
    private Date chatDate;
}
